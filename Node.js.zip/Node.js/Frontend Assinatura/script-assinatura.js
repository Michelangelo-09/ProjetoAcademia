const API_URL = 'http://localhost:3000';

const inputCpfBusca = document.getElementById('cpfBusca');
const btnBuscar = document.getElementById('btnBuscar');
const detalhesAssinatura = document.getElementById('detalhesAssinatura');

const spanNomeAluno = document.getElementById('nomeAluno');
const spanPlanoAtual = document.getElementById('planoAtual');
const spanPrecoAtual = document.getElementById('precoAtual');
const spanStatusPagamento = document.getElementById('statusPagamento');

const btnTrocar = document.getElementById('btnTrocar');
const btnRenovar = document.getElementById('btnRenovar');
const btnCancelar = document.getElementById('btnCancelar');

let assinaturaAtualId = null;

// Máscara automática de CPF
inputCpfBusca.addEventListener('input', (e) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11) value = value.slice(0, 11);
    
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    
    e.target.value = value;
});

// Buscar Assinatura por CPF
btnBuscar.addEventListener('click', async () => {
    const cpf = inputCpfBusca.value.trim();
    if (cpf.length < 14) {
        alert('Por favor, digite um CPF válido.');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/assinaturas`);
        const assinaturas = await response.json();

        if (!response.ok) {
            alert('Erro ao buscar dados do servidor.');
            return;
        }

        // Procura a assinatura pelo aluno_cpf retornado pelo banco
        const assinaturaEncontrada = assinaturas.find(a => a.aluno_cpf === cpf);

        if (!assinaturaEncontrada) {
            alert('Nenhuma assinatura ativa encontrada para este CPF.');
            detalhesAssinatura.style.display = 'none';
            return;
        }

        assinaturaAtualId = assinaturaEncontrada.assinatura_id;
        spanNomeAluno.textContent = assinaturaEncontrada.aluno_nome;
        spanPlanoAtual.textContent = assinaturaEncontrada.plano_nome;
        spanPrecoAtual.textContent = Number(assinaturaEncontrada.preco).toFixed(2);
        spanStatusPagamento.textContent = assinaturaEncontrada.pago ? 'Pago' : 'Pendente';
        spanStatusPagamento.style.color = assinaturaEncontrada.pago ? '#28a745' : '#ffc107';

        detalhesAssinatura.style.display = 'block';

    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao conectar com o servidor.');
    }
});

// Trocar de Plano
btnTrocar.addEventListener('click', async () => {
    const novoPlanoSelecionado = document.querySelector('input[name="novoPlano"]:checked');
    if (!novoPlanoSelecionado) {
        alert('Selecione um novo plano nas opções acima.');
        return;
    }

    const novoPlanoId = parseInt(novoPlanoSelecionado.value, 10);

    try {
        const response = await fetch(`${API_URL}/assinaturas/${assinaturaAtualId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ plano_id: novoPlanoId, pago: false })
        });

        if (response.ok) {
            alert('Plano alterado com sucesso!');
            btnBuscar.click(); // Atualiza as informações exibidas
        } else {
            const err = await response.json();
            alert(`Erro ao alterar plano: ${err.error}`);
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao conectar com o servidor.');
    }
});

// Renovar Assinatura (Marca o status como pago = true)
btnRenovar.addEventListener('click', async () => {
    try {
        const response = await fetch(`${API_URL}/assinaturas/${assinaturaAtualId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ pago: true })
        });

        if (response.ok) {
            alert('Assinatura renovada com sucesso!');
            btnBuscar.click();
        } else {
            const err = await response.json();
            alert(`Erro ao renovar assinatura: ${err.error}`);
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao conectar com o servidor.');
    }
});

// Cancelar Assinatura (Deleta o registro da assinatura)
btnCancelar.addEventListener('click', async () => {
    if (!confirm('Tem certeza que deseja cancelar sua assinatura?')) return;

    try {
        const response = await fetch(`${API_URL}/assinaturas/${assinaturaAtualId}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            alert('Assinatura cancelada com sucesso.');
            detalhesAssinatura.style.display = 'none';
            inputCpfBusca.value = '';
            assinaturaAtualId = null;
        } else {
            const err = await response.json();
            alert(`Erro ao cancelar assinatura: ${err.error}`);
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao conectar com o servidor.');
    }
});