require('dotenv').config();
const express = require('express');
const cors = require('cors');
const pool = require('./database');

const app = express();

app.use(cors());
app.use(express.json());

// ==========================================
// 1. CRUD DE ALUNOS
// ==========================================

// Criar/Verificar Aluno
app.post('/alunos', async (req, res) => {
  const { nome, idade, cpf } = req.body;
  try {
    const aluno = await pool.query('SELECT * FROM alunos WHERE cpf = $1', [cpf]);
    if (aluno.rows[0]) {
      return res.status(200).json(aluno.rows[0]);
    }
    const result = await pool.query(
      'INSERT INTO alunos (nome, idade, cpf) VALUES ($1, $2, $3) RETURNING *',
      [nome, idade, cpf]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Listar todos os Alunos
app.get('/alunos', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM alunos ORDER BY id ASC');
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Atualizar Aluno
app.put('/alunos/:id', async (req, res) => {
  const { id } = req.params;
  const { nome, idade, cpf } = req.body;
  try {
    const result = await pool.query(
      'UPDATE alunos SET nome = COALESCE($1, nome), idade = COALESCE($2, idade), cpf = COALESCE($3, cpf) WHERE id = $4 RETURNING *',
      [nome, idade, cpf, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Aluno não encontrado' });
    res.json(result.rows[0]);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Deletar Aluno
app.delete('/alunos/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM alunos WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Aluno não encontrado' });
    res.json({ message: 'Aluno removido com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==========================================
// 2. CRUD DE PLANOS
// ==========================================

app.post('/planos', async (req, res) => {
  const { nome, preco } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO planos (nome, preco) VALUES ($1, $2) RETURNING *',
      [nome, preco]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/planos', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM planos ORDER BY id ASC');
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/planos/:id', async (req, res) => {
  const { id } = req.params;
  const { nome, preco } = req.body;
  try {
    const result = await pool.query(
      'UPDATE planos SET nome = COALESCE($1, nome), preco = COALESCE($2, preco) WHERE id = $3 RETURNING *',
      [nome, preco, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Plano não encontrado' });
    res.json(result.rows[0]);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.delete('/planos/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM planos WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Plano não encontrado' });
    res.json({ message: 'Plano removido com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==========================================
// 3. CRUD DE ASSINATURAS
// ==========================================

app.post('/assinaturas', async (req, res) => {
  const { aluno_id, plano_id, pago } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO assinaturas (aluno_id, plano_id, pago) VALUES ($1, $2, $3) RETURNING *',
      [aluno_id, plano_id, pago ?? false]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// CORREÇÃO CRÍTICA: Retornando al.cpf como aluno_cpf
app.get('/assinaturas', async (req, res) => {
  try {
    const queryText = `
      SELECT 
        a.id AS assinatura_id,
        al.nome AS aluno_nome,
        al.cpf AS aluno_cpf,
        p.nome AS plano_nome,
        p.preco,
        a.pago
      FROM assinaturas a
      JOIN alunos al ON a.aluno_id = al.id
      JOIN planos p ON a.plano_id = p.id
      ORDER BY a.id ASC;
    `;
    const result = await pool.query(queryText);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/assinaturas/:id', async (req, res) => {
  const { id } = req.params;
  const { aluno_id, plano_id, pago } = req.body;
  try {
    const result = await pool.query(
      `UPDATE assinaturas 
       SET aluno_id = COALESCE($1, aluno_id), 
           plano_id = COALESCE($2, plano_id), 
           pago = COALESCE($3, pago) 
       WHERE id = $4 RETURNING *`,
      [aluno_id, plano_id, pago, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Assinatura não encontrada' });
    res.json(result.rows[0]);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.delete('/assinaturas/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM assinaturas WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Assinatura não encontrada' });
    res.json({ message: 'Assinatura removida com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Inicialização do Servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});