const API_URL = 'http://localhost:3000';

const formCadastro = document.getElementById('formCadastro');
const inputCpf = document.getElementById('cpf');

// Máscara automática de CPF
if (inputCpf) {
    inputCpf.addEventListener('input', (e) => {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length > 11) value = value.slice(0, 11);
        
        value = value.replace(/(\d{3})(\d)/, '$1.$2');
        value = value.replace(/(\d{3})(\d)/, '$1.$2');
        value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
        
        e.target.value = value;
    });
}

// Evento ao submeter o formulário
if (formCadastro) {
    formCadastro.addEventListener('submit', async (e) => {
        e.preventDefault();

        const planoSelecionado = document.querySelector('input[name="plano"]:checked');
        if (!planoSelecionado) {
            alert('Por favor, selecione um plano!');
            return;
        }

        const plano_id = planoSelecionado.value;
        const nome = document.getElementById('nome').value;
        const idade = parseInt(document.getElementById('idade').value, 10);
        const cpf = inputCpf.value;

        try {
            // 1. Cadastra ou identifica o aluno
            const responseAluno = await fetch(`${API_URL}/alunos`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nome, idade, cpf })
            });

            const dataAluno = await responseAluno.json();

            if (!responseAluno.ok) {
                alert(`Erro no cadastro: ${dataAluno.error || 'Verifique os dados.'}`);
                return;
            }

            // 2. Cria a assinatura com o plano escolhido
            const responseAssinatura = await fetch(`${API_URL}/assinaturas`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    aluno_id: dataAluno.id, 
                    plano_id: parseInt(plano_id, 10),
                    pago: false 
                })
            });

            if (responseAssinatura.ok) {
                alert('Plano selecionado e cadastro realizado com sucesso!');
                formCadastro.reset();
            } else {
                const dataAssinatura = await responseAssinatura.json();
                alert(`Erro ao registrar plano: ${dataAssinatura.error}`);
            }

        } catch (error) {
            console.error('Erro na requisição:', error);
            alert('Erro ao conectar com o servidor.');
        }
    });
}